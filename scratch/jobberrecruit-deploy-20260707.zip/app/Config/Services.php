<?php

namespace Config;

use CodeIgniter\Config\BaseService;
use App\Services\SocialAuthService;
use App\Services\PaystackService;

/**
 * Services Configuration file.
 *
 * Services are simply other classes/libraries that the system uses
 * to do its job. This is used by CodeIgniter to allow the core of the
 * framework to be swapped out easily without affecting the usage within
 * the rest of your application.
 *
 * This file holds any application-specific services, or service overrides
 * that you might need. An example has been included with the general
 * method format you should use for your service methods. For more examples,
 * see the core Services file at system/Config/Services.php.
 */
class Services extends BaseService
{
    public static bool $bypassQueue = false;

    /*
     * public static function example($getShared = true)
     * {
     *     if ($getShared) {
     *         return static::getSharedInstance('example');
     *     }
     *
     *     return new \CodeIgniter\Example();
     * }
     */

    public static function email($getShared = true)
    {
        if ($getShared && !static::$bypassQueue) {
            return static::getSharedInstance('email');
        }

        $config = config('Email');

        if (static::$bypassQueue) {
            return new \CodeIgniter\Email\Email($config);
        }

        return new \App\Libraries\QueuedEmail($config);
    }

    public static function socialAuth(bool $getShared = true): SocialAuthService
    {
        if ($getShared) {
            return static::getSharedInstance('socialAuth');
        }

        return new SocialAuthService();
    }

    public static function mailer($getShared = true)
    {
        if ($getShared) {
            return static::getSharedInstance('mailer');
        }
        return new \App\Services\Mailer();
    }

    public static function paystack(bool $getShared = true): PaystackService
    {
        if ($getShared) {
            return static::getSharedInstance('paystack');
        }

        return new PaystackService();
    }
}
