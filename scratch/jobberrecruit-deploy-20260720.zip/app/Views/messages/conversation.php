<?= $this->extend(auth()->user()->user_type === 'employer' ? 'layouts/employer' : 'layouts/app') ?>

<?= $this->section('content') ?>
<div class="page-hd">
    <div class="page-hd-left">
        <h1 style="display: flex; align-items: center; gap: 10px;">
            <a href="<?= base_url(auth()->user()->user_type === 'employer' ? 'employer/messages' : 'candidate/messages') ?>" class="ic-btn" style="width: 36px; height: 36px; border-radius: 50%;">
                <svg aria-hidden="true" style="width: 14px; height: 14px;"><use href="#i-arrow-l"/></svg>
            </a>
            Messages
        </h1>
    </div>
</div>

<div class="card">
    <div class="card-head" style="background: var(--bg); display: flex; align-items: center; gap: 12px; padding: 12px 20px;">
        <?php
            $user = auth()->user();
            if ($user->user_type === 'employer') {
                $name = $otherParty->full_name ?? 'Candidate';
                $avatar = $otherParty->profile_photo ?? '';
            } else {
                $name = $otherParty->company_name ?? 'Employer';
                $avatar = $otherParty->logo ?? '';
            }

            $hasAvatar = false;
            $avatarUrl = '';
            if (!empty($avatar)) {
                if (filter_var($avatar, FILTER_VALIDATE_URL) || str_starts_with($avatar, 'http://') || str_starts_with($avatar, 'https://')) {
                    $avatarUrl = $avatar;
                    $hasAvatar = true;
                } elseif (file_exists(FCPATH . $avatar)) {
                    $avatarUrl = base_url($avatar);
                    $hasAvatar = true;
                }
            }

            $initials = '';
            $words = explode(' ', preg_replace('/\s+/', ' ', trim($name)));
            if (count($words) >= 2) {
                $initials = strtoupper(substr($words[0], 0, 1) . substr($words[1], 0, 1));
            } else {
                $initials = strtoupper(substr($name, 0, 2));
            }
        ?>
        <?php if ($hasAvatar): ?>
            <img src="<?= $avatarUrl ?>" class="msg-ava" style="width:40px; height:40px; object-fit: cover;" alt="">
        <?php else: ?>
            <span class="msg-ava" style="width:40px; height:40px; font-size:0.75rem;">
                <?= esc($initials) ?>
            </span>
        <?php endif; ?>
        <div>
            <h3 style="font-size: 0.92rem; font-weight: 700; color: var(--brand-deep); margin: 0;"><?= esc($name) ?></h3>
            <?php if (!empty($conversation['job_id'])): ?>
                <small style="font-size: 0.74rem; color: var(--muted);">Regarding: <?= esc($conversation['job_title'] ?? 'a job') ?></small>
            <?php endif; ?>
        </div>
    </div>

    <div class="card-body p-0 msg-bubble-wrap" style="max-height: 500px; overflow-y: auto; background: var(--bg); padding: 20px;" id="messageContainer">
        <?php if (empty($messages)): ?>
            <div class="text-center py-4">
                <p class="text-muted">No messages yet. Start the conversation!</p>
            </div>
        <?php else: ?>
            <div style="display: flex; flex-direction: column; gap: 12px; width: 100%;">
                <?php foreach ($messages as $msg): ?>
                    <?php $isOwn = $msg['sender_id'] == $user->id; ?>
                    <div class="msg-bubble <?= $isOwn ? 'msg-bubble--out' : 'msg-bubble--in' ?>">
                        <p style="margin: 0; font-size: 0.86rem; word-break: break-word;"><?= nl2br(esc($msg['message'])) ?></p>
                        <small style="font-size: 0.64rem; opacity: 0.7; display: block; text-align: right; margin-top: 4px;">
                            <?= date('g:i A', strtotime($msg['created_at'])) ?>
                        </small>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
    </div>

    <div class="card-head msg-input-bar" style="background: #fff; padding: 12px 20px; border-top: 1px solid var(--border);">
        <form id="messageForm" style="display: flex; gap: 10px; width: 100%; align-items: center;">
            <input type="hidden" name="conversation_id" value="<?= $conversation['id'] ?>">
            <input type="hidden" name="recipient_id" value="<?= $user->user_type === 'employer' ? $conversation['job_seeker_id'] : $conversation['employer_id'] ?>">
            <input type="text" id="messageInput" class="form-control" placeholder="Type a message..." required autocomplete="off" style="flex:1; min-height:40px;">
            <button type="submit" class="emp-btn emp-btn-primary" id="sendBtn" style="min-height: 40px; padding: 0 16px; border-radius: 8px;">
                <svg aria-hidden="true" style="width:14px; height:14px;"><use href="#i-send"/></svg>
            </button>
        </form>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    var container = document.getElementById('messageContainer');
    if (container) container.scrollTop = container.scrollHeight;

    var csrfToken = document.querySelector('meta[name="csrf-token"]')?.content || '';
    var csrfHeader = 'X-CSRF-TOKEN';

    document.getElementById('messageForm').addEventListener('submit', function(e) {
        e.preventDefault();
        var input = document.getElementById('messageInput');
        var sendBtn = document.getElementById('sendBtn');
        var msg = input.value.trim();
        if (!msg) return;

        sendBtn.disabled = true;

        var formData = new FormData();
        formData.append('message', msg);
        formData.append('recipient_id', this.querySelector('[name="recipient_id"]').value);
        formData.append('job_id', '<?= $conversation['job_id'] ?? 0 ?>');

        var sendUrl = '<?= base_url(auth()->user()->user_type === "employer" ? "employer/messages/send" : "candidate/messages/send") ?>';

        fetch(sendUrl, {
            method: 'POST',
            headers: {
                [csrfHeader]: csrfToken
            },
            body: formData
        })
        .then(r => r.json())
        .then(data => {
            if (data.success || data.status === 'success') {
                var bubbleWrap = container.querySelector('div') || container;
                var div = document.createElement('div');
                div.className = 'msg-bubble msg-bubble--out';
                div.innerHTML = `<p style="margin: 0; font-size: 0.86rem; word-break: break-word;">${msg.replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/\n/g, '<br>')}</p>
                    <small style="font-size: 0.64rem; opacity: 0.7; display: block; text-align: right; margin-top: 4px;">Just now</small>`;
                bubbleWrap.appendChild(div);
                container.scrollTop = container.scrollHeight;
                input.value = '';
            } else {
                alert(data.message || 'Failed to send message');
            }
            sendBtn.disabled = false;
        })
        .catch(err => {
            console.error('Error sending message:', err);
            alert('Network error. Please try again.');
            sendBtn.disabled = false;
        });
    });

    if (container) container.scrollTop = container.scrollHeight;
});
</script>
<?= $this->endSection() ?>
