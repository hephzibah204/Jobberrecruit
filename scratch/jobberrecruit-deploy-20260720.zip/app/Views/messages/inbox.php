<?= $this->extend(auth()->user()->user_type === 'employer' ? 'layouts/employer' : 'layouts/app') ?>

<?= $this->section('content') ?>
<div class="page-hd">
    <div class="page-hd-left">
        <h1>Messages</h1>
        <p>Communicate with candidates and employers</p>
    </div>
    <?php if ($unreadCount > 0): ?>
        <span class="pill pill--rejected"><?= $unreadCount ?> unread</span>
    <?php endif; ?>
</div>

<div class="card">
    <div class="card-body" style="padding: 0;">
        <?php if (empty($conversations)): ?>
            <div class="empty-state">
                <div class="empty-ic">
                    <svg aria-hidden="true" style="width:24px; height:24px;"><use href="#i-chat"/></svg>
                </div>
                <h3>No messages yet</h3>
                <p>Start a conversation by unlocking a candidate's profile.</p>
            </div>
        <?php else: ?>
            <div class="msg-list" style="border-right: none;">
                <?php foreach ($conversations as $conv): ?>
                    <?php
                        $user = auth()->user();
                        if ($user->user_type === 'employer') {
                            $name = $conv['seeker_name'] ?? 'Unknown';
                            $rawAvatar = $conv['profile_photo'] ?? '';
                            $subtitle = $conv['job_title'] ?? '';
                        } else {
                            $name = $conv['company_name'] ?? 'Unknown';
                            $rawAvatar = $conv['employer_logo'] ?? '';
                            $subtitle = $conv['job_title'] ?? '';
                        }

                        $hasAvatar = false;
                        $avatarUrl = '';
                        if (!empty($rawAvatar)) {
                            if (filter_var($rawAvatar, FILTER_VALIDATE_URL) || str_starts_with($rawAvatar, 'http://') || str_starts_with($rawAvatar, 'https://')) {
                                $avatarUrl = $rawAvatar;
                                $hasAvatar = true;
                            } elseif (file_exists(FCPATH . $rawAvatar)) {
                                $avatarUrl = base_url($rawAvatar);
                                $hasAvatar = true;
                            }
                        }

                        $initials = '';
                        $words = explode(' ', preg_replace('/\s+/', ' ', trim($name)));
                        if (count($words) >= 2) {
                            $initials = strtoupper(substr($words[0], 0, 1) . substr($words[1], 0, 1));
                        } else {
                            $initials = strtoupper(substr($name, 0, 2));
                        }

                        $lastMsg = $conv['last_message'] ?? '';
                        $lastAt = isset($conv['last_message_at']) ? date('M j, g:i A', strtotime($conv['last_message_at'])) : '';
                        $convUrl = $user->user_type === 'employer'
                            ? base_url('employer/messages/conversation/' . $conv['id'])
                            : base_url('candidate/messages/conversation/' . $conv['id']);
                    ?>
                    <a href="<?= $convUrl ?>" class="msg-item" style="text-decoration: none;">
                        <?php if ($hasAvatar): ?>
                            <img src="<?= $avatarUrl ?>" class="msg-ava" style="object-fit: cover;" alt="">
                        <?php else: ?>
                            <span class="msg-ava">
                                <?= esc($initials) ?>
                            </span>
                        <?php endif; ?>
                        <div style="flex: 1; min-width: 0;">
                            <div style="display: flex; justify-content: space-between; align-items: center; gap: 8px;">
                                <h4 class="ins-title" style="font-size: 0.9rem; font-weight: 700; color: var(--brand-deep); margin: 0;"><?= esc($name) ?></h4>
                                <small style="font-size: 0.72rem; color: var(--muted); white-space: nowrap;"><?= $lastAt ?></small>
                            </div>
                            <?php if ($subtitle): ?>
                                <small style="font-size: 0.76rem; color: var(--brand); font-weight: 600; display: block; margin-top: 2px;"><?= esc($subtitle) ?></small>
                            <?php endif; ?>
                            <p style="font-size: 0.8rem; color: var(--muted); margin: 4px 0 0; white-space: nowrap; overflow: hidden; text-overflow: ellipsis;"><?= esc($lastMsg) ?></p>
                        </div>
                    </a>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
    </div>
</div>
<?= $this->endSection() ?>
