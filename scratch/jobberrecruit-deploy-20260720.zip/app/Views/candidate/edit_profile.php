<?= $this->extend('layouts/app') ?>

<?= $this->section('styles') ?>
<link rel="stylesheet" href="<?= base_url('css/candidate-profile.css') ?>">
<?= $this->endSection() ?>

<?= $this->section('content') ?>
<?php
// Retrieve Escrow Wallet balance
$walletModel = new \App\Models\WalletModel();
$wallet = $walletModel->where('user_id', $user->id)->first();
$walletBalance = $wallet ? $wallet->balance : 0;

// Dynamic Profile completion calculation
$fields = [
    'full_name',
    'dob',
    'gender',
    'phone',
    'location',
    'job_title',
    'employment_type',
    'skills',
    'experience_years',
    'education_level',
];

$completed = 0;
foreach ($fields as $f) {
    if (!empty($candidate->$f)) $completed++;
}
if (!empty($candidate->resume)) $completed++;
$totalFields = count($fields) + 1;
$completion = round(($completed / $totalFields) * 100);

// Calculate section-by-section completion status
$basicComplete = !empty($candidate->full_name) && !empty($candidate->phone) && !empty($candidate->state_id);
$careerComplete = !empty($candidate->job_title) && !empty($candidateIndustryIds);
$docsComplete = !empty($candidate->resume);
?>

<div class="content">
    
    <!-- Header -->
    <div class="page-head">
        <div>
            <h1><svg aria-hidden="true" style="width:22px;height:22px;fill:none;stroke:currentColor;stroke-width:2;"><use href="#i-edit"/></svg> Edit Candidate Profile</h1>
            <p>Update your personal, career, and document information</p>
        </div>
        <div class="page-actions">
            <a href="<?= base_url('candidate/profile') ?>" class="btn btn-outline btn-sm">
                Back to Profile
            </a>
        </div>
    </div>

    <!-- PROFILE PROGRESS & WALLET BANNER -->
    <div class="progress-bar">
        <div class="progress-inner">
            <div class="progress-left">
                <div class="progress-track" aria-hidden="true">
                    <div class="progress-fill" style="width: <?= $completion ?>%;"></div>
                    <div class="milestone-marker <?= $completion >= 60 ? 'achieved' : 'next' ?>" style="left: 60%;" title="Earn ₦200 at 60%">
                        <span class="milestone-label">₦200</span>
                    </div>
                    <div class="milestone-marker <?= $completion >= 80 ? 'achieved' : ($completion >= 60 ? 'next' : '') ?>" style="left: 80%;" title="Earn ₦500 at 80%">
                        <span class="milestone-label">₦500</span>
                    </div>
                </div>
                <span class="progress-text"><?= $completion ?>% Completed</span>
                <span class="progress-tip">
                    <svg aria-hidden="true" style="width:13px;height:13px;fill:none;stroke:currentColor;stroke-width:2;"><use href="#i-zap"/></svg>
                    <span>
                        <?php if ($completion < 60): ?>
                            Complete <?= 60 - $completion ?>% more to unlock ₦200
                        <?php elseif ($completion < 80): ?>
                            Nice! Complete <?= 80 - $completion ?>% more to unlock ₦500
                        <?php else: ?>
                            All profile milestones achieved!
                        <?php endif; ?>
                    </span>
                </span>
            </div>
            <div class="progress-actions">
                <span class="wallet-chip <?= $walletBalance > 0 ? 'has-balance' : '' ?>">
                    <svg aria-hidden="true" style="width:13px;height:13px;fill:none;stroke:currentColor;stroke-width:2;"><use href="#i-wallet"/></svg>
                    <span class="wallet-label">Wallet:</span>
                    <span>₦<?= number_format($walletBalance, 2) ?></span>
                </span>
            </div>
        </div>
    </div>

    <form action="<?= base_url('candidate/profile/edit') ?>"
        method="POST"
        enctype="multipart/form-data"
        id="editCandidateForm">

        <?= csrf_field() ?>

        <div class="add-candidate" style="display:flex;flex-direction:column;gap:20px;margin-top:20px;">
            <!-- 1. BASIC INFORMATION -->
            <details class="cv-card <?= $basicComplete ? 'is-complete' : '' ?>" open>
                <summary class="cv-card-header">
                    <span class="cv-card-title"><svg aria-hidden="true" style="width:18px;height:18px;fill:none;stroke:currentColor;stroke-width:2;"><use href="#i-users"/></svg> Basic Information</span>
                    <span class="cv-card-done <?= $basicComplete ? 'complete' : 'incomplete' ?>"><?= $basicComplete ? 'Complete' : 'Incomplete' ?></span>
                    <svg class="cv-chev" aria-hidden="true" style="width:18px;height:18px;fill:none;stroke:currentColor;stroke-width:2;"><use href="#i-arrow-r"/></svg>
                </summary>
                <div class="cv-card-body">
                    <div class="cv-card-hint">
                        Provide your core contact details. Ensure your phone number is correct so recruiters can reach you easily.
                    </div>
                    <div class="form-grid">
                        <div class="form-field">
                            <label>User ID</label>
                            <input type="text" class="input" value="<?= esc($candidate->user_id) ?>" readonly style="background:#e9ecef;">
                        </div>
                        <div class="form-field">
                            <label>Full Name<span class="text-danger">*</span></label>
                            <input type="text" name="full_name" class="input"
                                value="<?= old('full_name', $candidate->full_name) ?>" required>
                        </div>
                        <div class="form-field">
                            <label>Date of Birth</label>
                            <input type="date" name="dob" class="input"
                                value="<?= old('dob', $candidate->dob) ?>">
                        </div>
                        <div class="form-field">
                            <label>Gender</label>
                            <select name="gender" class="select">
                                <option value="" selected disabled>Select</option>
                                <option value="male" <?= $candidate->gender == 'male' ? 'selected' : '' ?>>Male</option>
                                <option value="female" <?= $candidate->gender == 'female' ? 'selected' : '' ?>>Female</option>
                                <option value="other" <?= $candidate->gender == 'other' ? 'selected' : '' ?>>Other</option>
                            </select>
                        </div>
                        <div class="form-field">
                            <label>Phone Number<span class="text-danger">*</span></label>
                            <input type="text" name="phone" class="input"
                                value="<?= old('phone', $candidate->phone) ?>" required>
                        </div>
                        <div class="form-field">
                            <label>State of Residence<span class="text-danger">*</span></label>
                            <select name="state_id" class="select" required>
                                <option value="">Select State</option>
                                <?php foreach ($states as $state): ?>
                                    <option value="<?= $state->id ?>"
                                        <?= $candidate->state_id == $state->id ? 'selected' : '' ?>>
                                        <?= esc($state->name) ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="form-field">
                            <label>State Area / Detailed Address</label>
                            <input type="text" name="location" class="input"
                                value="<?= old('location', $candidate->location) ?>" placeholder="e.g. Ikeja, Lagos">
                        </div>
                        <div class="form-field">
                            <label>Availability</label>
                            <select name="availability" class="select">
                                <option value="" disabled selected>Select</option>
                                <option value="immediately" <?= $candidate->availability == 'immediately' ? 'selected' : '' ?>>Immediately</option>
                                <option value="1-week" <?= $candidate->availability == '1-week' ? 'selected' : '' ?>>1 Week</option>
                                <option value="1-month" <?= $candidate->availability == '1-month' ? 'selected' : '' ?>>1 Month</option>
                                <option value="2-months" <?= $candidate->availability == '2-months' ? 'selected' : '' ?>>2 Months</option>
                            </select>
                        </div>
                        <div class="form-field full">
                            <label>Short Bio / Professional Summary</label>
                            <textarea name="description" class="input" rows="4" placeholder="Summarize your career, years of experience, and key value..."><?= old('description', $candidate->description ?? '') ?></textarea>
                        </div>
                    </div>
                </div>
            </details>

            <!-- 2. CAREER INFORMATION -->
            <details class="cv-card <?= $careerComplete ? 'is-complete' : '' ?>" open>
                <summary class="cv-card-header">
                    <span class="cv-card-title"><svg aria-hidden="true" style="width:18px;height:18px;fill:none;stroke:currentColor;stroke-width:2;"><use href="#i-briefcase"/></svg> Career & Professional Details</span>
                    <span class="cv-card-done <?= $careerComplete ? 'complete' : 'incomplete' ?>"><?= $careerComplete ? 'Complete' : 'Incomplete' ?></span>
                    <svg class="cv-chev" aria-hidden="true" style="width:18px;height:18px;fill:none;stroke:currentColor;stroke-width:2;"><use href="#i-arrow-r"/></svg>
                </summary>
                <div class="cv-card-body">
                    <div class="cv-card-hint">
                        Highlight your professional background, target job title, target industries, and skills below.
                    </div>
                    <div class="form-grid">
                        <div class="form-field">
                            <label>Target Job Title<span class="text-danger">*</span></label>
                            <input type="text" name="job_title" class="input"
                                value="<?= old('job_title', $candidate->job_title) ?>" placeholder="e.g. Senior Software Engineer" required>
                        </div>
                        <div class="form-field">
                            <label>Preferred Employment Type</label>
                            <select name="employment_type" class="select">
                                <option value="">Select</option>
                                <option value="Full Time" <?= $candidate->employment_type == 'Full Time' ? 'selected' : '' ?>>Full Time</option>
                                <option value="Part Time" <?= $candidate->employment_type == 'Part Time' ? 'selected' : '' ?>>Part Time</option>
                                <option value="Remote" <?= $candidate->employment_type == 'Remote' ? 'selected' : '' ?>>Remote</option>
                                <option value="Contract" <?= $candidate->employment_type == 'Contract' ? 'selected' : '' ?>>Contract</option>
                                <option value="Internship" <?= $candidate->employment_type == 'Internship' ? 'selected' : '' ?>>Internship</option>
                            </select>
                        </div>
                        <div class="form-field">
                            <label>Years of Experience</label>
                            <input type="number" name="experience_years" class="input"
                                value="<?= old('experience_years', $candidate->experience_years) ?>" placeholder="e.g. 5">
                        </div>
                        <div class="form-field">
                            <label>Highest Education Level</label>
                            <select name="education_level" class="select">
                                <option value="" disabled selected>Select level</option>
                                <option value="High School" <?= $candidate->education_level == 'High School' ? 'selected' : '' ?>>High School</option>
                                <option value="Undergraduate" <?= $candidate->education_level == 'Undergraduate' ? 'selected' : '' ?>>Undergraduate</option>
                                <option value="Diploma" <?= $candidate->education_level == 'Diploma' ? 'selected' : '' ?>>Diploma</option>
                                <option value="Bachelor's Degree" <?= $candidate->education_level == "Bachelor's Degree" ? 'selected' : '' ?>>Bachelor's Degree</option>
                                <option value="Master's Degree" <?= $candidate->education_level == "Master's Degree" ? 'selected' : '' ?>>Master's Degree</option>
                                <option value="PhD" <?= $candidate->education_level == 'PhD' ? 'selected' : '' ?>>PhD</option>
                                <option value="Professional Certification" <?= $candidate->education_level == 'Professional Certification' ? 'selected' : '' ?>>Professional Certification</option>
                                <option value="Others" <?= $candidate->education_level == 'Others' ? 'selected' : '' ?>>Others</option>
                            </select>
                        </div>
                        <div class="form-field">
                            <label>Desired Salary (Amount in ₦)</label>
                            <input type="number" name="desired_salary" class="input"
                                value="<?= old('desired_salary', $candidate->desired_salary) ?>" placeholder="e.g. 250000">
                        </div>
                        <div class="form-field">
                            <label>Salary Period</label>
                            <select name="salary_type" class="select">
                                <option value="" disabled selected>Select</option>
                                <option value="hourly" <?= ($candidate->salary_type ?? '') == 'hourly' ? 'selected' : '' ?>>Hourly</option>
                                <option value="monthly" <?= ($candidate->salary_type ?? '') == 'monthly' ? 'selected' : '' ?>>Monthly</option>
                                <option value="yearly" <?= ($candidate->salary_type ?? '') == 'yearly' ? 'selected' : '' ?>>Yearly</option>
                            </select>
                        </div>
                        <div class="form-field">
                            <label>Languages (Comma separated)</label>
                            <input type="text" name="languages" class="input"
                                value="<?= old('languages', $candidate->languages) ?>" placeholder="English, Yoruba, French">
                        </div>
                        <div class="form-field">
                            <label>Portfolio Website URL</label>
                            <input type="text" name="portfolio" class="input"
                                value="<?= old('portfolio', $candidate->portfolio) ?>" placeholder="https://myportfolio.com">
                        </div>
                        <div class="form-field full">
                            <label>Skills (Comma separated list)</label>
                            <textarea name="skills" class="input" rows="3"
                                placeholder="e.g. PHP, UI/UX Design, Figma, React, Communication"><?= old('skills', $candidate->skills) ?></textarea>
                        </div>
                        <div class="form-field full">
                            <label>Target Industries (Hold Ctrl/Cmd to select multiple)<span class="text-danger">*</span></label>
                            <select class="select select2" name="industry_ids[]" multiple required style="min-height: 120px;">
                                <?php foreach ($industries as $industry): ?>
                                    <optgroup label="<?= esc($industry->name) ?>">
                                        <?php foreach ($industry->children as $child): ?>
                                            <option value="<?= $child->id ?>"
                                                <?= in_array($child->id, $candidateIndustryIds ?? []) ? 'selected' : '' ?>>
                                                <?= esc($child->name) ?>
                                            </option>
                                        <?php endforeach; ?>
                                    </optgroup>
                                <?php endforeach; ?>
                            </select>
                        </div>
                    </div>
                </div>
            </details>

            <!-- 3. DOCUMENTS & UPLOADS -->
            <details class="cv-card <?= $docsComplete ? 'is-complete' : '' ?>" open>
                <summary class="cv-card-header">
                    <span class="cv-card-title"><svg aria-hidden="true" style="width:18px;height:18px;fill:none;stroke:currentColor;stroke-width:2;"><use href="#i-doc"/></svg> Profile Picture &amp; Resume</span>
                    <span class="cv-card-done <?= $docsComplete ? 'complete' : 'optional' ?>"><?= $docsComplete ? 'Complete' : 'Optional' ?></span>
                    <svg class="cv-chev" aria-hidden="true" style="width:18px;height:18px;fill:none;stroke:currentColor;stroke-width:2;"><use href="#i-arrow-r"/></svg>
                </summary>
                <div class="cv-card-body">
                    <div class="cv-card-hint">
                        Upload a professional headshot and your latest resume in PDF or Word format.
                    </div>
                    <div class="form-grid">
                        <!-- PROFILE PICTURE -->
                        <div class="form-field">
                            <label>Profile Picture</label>
                            <div class="photo-upload-container mb-3" style="display:flex;gap:15px;align-items:center;">
                                <div class="photo-preview-wrapper" style="width:80px;height:80px;border-radius:50%;overflow:hidden;background:#f5f7fb;display:flex;align-items:center;justify-content:center;border:1px solid var(--border);">
                                    <?php if (!empty($candidate->profile_picture)): ?>
                                        <img src="<?= base_url($candidate->profile_picture) ?>" id="currentProfilePic" alt="Profile pic" style="width:100%;height:100%;object-fit:cover;">
                                    <?php else: ?>
                                        <svg aria-hidden="true" style="width:30px;height:30px;color:var(--muted);fill:none;stroke:currentColor;stroke-width:2;"><use href="#i-users"/></svg>
                                    <?php endif; ?>
                                    <img id="profilePreviewImg" style="display: none; width: 100%; height: 100%; object-fit: cover;" alt="">
                                </div>
                                <div style="flex:1;">
                                    <input type="file" name="profile_picture" id="profileInput" accept="image/*" class="input mb-2">
                                    <?php if (!empty($candidate->profile_picture)): ?>
                                        <div class="form-check" style="display:flex;align-items:center;gap:6px;">
                                            <input type="checkbox" name="remove_profile_picture" id="removePic" class="form-check-input" value="1">
                                            <label for="removePic" class="text-muted small">Remove current picture</label>
                                        </div>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>

                        <!-- RESUME -->
                        <div class="form-field">
                            <label>Resume / CV Document</label>
                            <div class="mb-3">
                                <input type="file" name="resume" id="resumeInput" accept=".pdf,.doc,.docx" class="input mb-2">
                                <?php if (!empty($candidate->resume)): ?>
                                    <div style="display:flex;align-items:center;gap:10px;">
                                        <a href="<?= base_url($candidate->resume) ?>" target="_blank" class="btn btn-outline btn-sm">
                                            <svg aria-hidden="true" style="width:14px;height:14px;fill:none;stroke:currentColor;stroke-width:2;"><use href="#i-doc"/></svg> View Current CV
                                        </a>
                                        <div class="form-check" style="display:flex;align-items:center;gap:6px;margin:0;">
                                            <input type="checkbox" name="remove_resume" id="removeResume" class="form-check-input" value="1">
                                            <label for="removeResume" class="text-muted small">Remove CV</label>
                                        </div>
                                    </div>
                                <?php endif; ?>
                            </div>
                            <div id="resumePreview" style="display: none;" class="mt-2">
                                <div class="border rounded p-2 d-inline-flex align-items-center" style="background:#f5f7fb;">
                                    <svg aria-hidden="true" style="width:16px;height:16px;color:var(--brand);margin-right:8px;fill:none;stroke:currentColor;stroke-width:2;"><use href="#i-doc"/></svg>
                                    <span id="resumePreviewText" class="small"></span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </details>
        </div>

        <!-- SAVE BUTTON -->
        <div class="bottom-actions" style="display:flex;justify-content:flex-end;margin-top:20px;gap:12px;">
            <a href="<?= base_url('candidate/profile') ?>" class="btn btn-outline">Cancel</a>
            <button type="submit" class="btn btn-primary" id="submitBtn">
                <span class="btn-text">Update Profile</span>
                <span class="spinner d-none" role="status" aria-hidden="true"></span>
            </button>
        </div>
    </form>
</div>
<?= $this->endSection() ?>

<?= $this->section('scripts') ?>
<script>
    $(document).ready(function() {
        // Initialize Select2 if exists
        if ($.fn.select2) {
            $('.select2').select2({
                placeholder: "Select industries",
                width: '100%'
            });
        }

        // Portfolio auto-prefix + validation
        const portfolioInput = $('input[name="portfolio"]');
        portfolioInput.on('blur', function() {
            let value = $(this).val().trim();
            if (!value) {
                $(this).removeClass('is-invalid');
                return;
            }
            if (!/^https?:\/\//i.test(value)) {
                value = 'https://' + value;
            }
            try {
                const url = new URL(value);
                const hostname = url.hostname;
                if (!hostname.includes('.') || hostname.split('.').pop().length < 2) {
                    throw new Error('Invalid domain');
                }
                $(this).val(value);
                $(this).removeClass('is-invalid');
            } catch (e) {
                $(this).addClass('is-invalid');
                toastr.error('Please enter a valid portfolio URL (e.g. example.com)');
            }
        });

        // Profile Picture Preview
        $('#profileInput').on('change', function(e) {
            const file = e.target.files[0];
            if (file && file.type.startsWith('image/')) {
                const reader = new FileReader();
                reader.onload = function(e) {
                    $('#profilePreviewImg').attr('src', e.target.result).show();
                    $('#currentProfilePic').hide();
                };
                reader.readAsDataURL(file);
            } else if (file) {
                toastr.warning("Invalid image file selected.");
                $(this).val('');
            }
        });

        // Resume Preview
        $('#resumeInput').on('change', function(e) {
            const file = e.target.files[0];
            if (file) {
                $('#resumePreviewText').text(file.name);
                $('#resumePreview').show();
            } else {
                $('#resumePreview').hide();
            }
        });

        // Ajax form submit
        $('#editCandidateForm').on('submit', function(e) {
            e.preventDefault();

            let btn = $('#submitBtn'),
                text = btn.find('.btn-text'),
                spin = btn.find('.spinner');

            btn.prop('disabled', true);
            text.addClass('d-none');
            spin.removeClass('d-none');

            // Website Normalization/Validation
            let portfolioVal = portfolioInput.val().trim();
            if (portfolioVal) {
                if (!/^https?:\/\//i.test(portfolioVal)) {
                    portfolioVal = 'https://' + portfolioVal;
                }
                try {
                    const url = new URL(portfolioVal);
                    if (!url.hostname.includes('.') || url.hostname.split('.').pop().length < 2) {
                        throw new Error();
                    }
                    portfolioInput.val(portfolioVal);
                } catch {
                    toastr.error('Please enter a valid portfolio URL.');
                    portfolioInput.addClass('is-invalid');
                    btn.prop('disabled', false);
                    text.removeClass('d-none');
                    spin.addClass('d-none');
                    return;
                }
            }

            const formData = new FormData(this);
            $.ajax({
                url: this.action,
                type: "POST",
                data: formData,
                processData: false,
                contentType: false,
                success: function(res) {
                    btn.prop('disabled', false);
                    text.removeClass('d-none');
                    spin.addClass('d-none');

                    if (res.status === 'error') {
                        toastr.error(res.message);
                    } else {
                        toastr.success(res.message);
                        window.location.href = "<?= base_url('candidate/profile') ?>";
                    }
                },
                error: function(xhr) {
                    btn.prop('disabled', false);
                    text.removeClass('d-none');
                    spin.addClass('d-none');

                    let msg = "Something went wrong.";
                    if (xhr.responseJSON && xhr.responseJSON.errors) {
                        msg = Object.values(xhr.responseJSON.errors).flat().join("<br>");
                    }
                    toastr.error(msg);
                }
            });
        });
    });
</script>
<?= $this->endSection() ?>