<?= $this->extend('layouts/app') ?>

<?= $this->section('styles') ?>
<link rel="stylesheet" href="<?= base_url('css/candidate-profile.css') ?>">
<style>
.session-history-item {
    background: var(--bg);
    border: 1px solid var(--border);
    border-radius: 10px;
    padding: 16px;
    transition: var(--transition);
}
.session-history-item:hover {
    border-color: var(--brand);
    background: var(--white);
    box-shadow: var(--shadow);
}
.text-brand { color: var(--brand) !important; }
@media (min-width: 992px) {
    .mock-interview-grid { grid-template-columns: 1.4fr 1fr; }
}
</style>
<?= $this->endSection() ?>

<?= $this->section('content') ?>
<?php
$recentSessions = $recentSessions ?? [];
$contextPreset = $contextPreset ?? [];
$questionPackLabels = [
    'general' => 'General / Behavioral',
    'engineering' => 'Engineering & Tech',
    'product' => 'Product Management',
    'sales' => 'Sales & Business Development',
    'marketing' => 'Marketing & Growth',
    'support' => 'Customer Success & Support',
    'operations' => 'Operations & Strategy',
];
?>

<div class="content">
    
    <!-- Header -->
    <div class="page-head">
        <div>
            <h1><svg aria-hidden="true" style="width:22px;height:22px;fill:none;stroke:currentColor;stroke-width:2;"><use href="#i-mic"/></svg> AI Mock Interview Control Center</h1>
            <p>Prepare and practice for your next big career opportunity with our advanced AI interviewer.</p>
        </div>
        <div class="page-actions">
            <a href="<?= base_url('candidate/career-tools') ?>" class="btn btn-outline btn-sm">
                <svg aria-hidden="true" style="width:14px;height:14px;fill:none;stroke:currentColor;stroke-width:2;"><use href="#i-arrow-l"/></svg> Back to Tools
            </a>
        </div>
    </div>

    <!-- Stats row -->
    <section class="stats" aria-label="Your interview performance" style="display:grid; grid-template-columns: repeat(auto-fit, minmax(220px, 1fr)); gap: 16px;">
        <div class="stat">
            <div class="stat-top">
                <span class="stat-ic"><svg aria-hidden="true" style="width:17px;height:17px;fill:none;stroke:currentColor;stroke-width:2;"><use href="#i-chat"/></svg></span>
            </div>
            <div class="stat-num"><?= count($recentSessions) ?></div>
            <div class="stat-lbl">Completed Interviews</div>
        </div>
        <div class="stat" style="--st-bar:var(--brand-dark)">
            <div class="stat-top">
                <span class="stat-ic"><svg aria-hidden="true" style="width:17px;height:17px;fill:none;stroke:currentColor;stroke-width:2;"><use href="#i-chart"/></svg></span>
            </div>
            <div class="stat-num">
                <?php
                    $avgScore = 0;
                    if (count($recentSessions) > 0) {
                        $scores = array_column($recentSessions, 'overall_score');
                        $avgScore = round(array_sum($scores) / count($recentSessions), 1);
                    }
                    echo $avgScore > 0 ? $avgScore . '<span style="font-size:.6em">/10</span>' : 'N/A';
                ?>
            </div>
            <div class="stat-lbl">Average Score</div>
        </div>
        <div class="stat" style="--st-bar:var(--accent);--st-icbg:var(--accent-light);--st-ic:var(--accent-dark)">
            <div class="stat-top">
                <span class="stat-ic"><svg aria-hidden="true" style="width:17px;height:17px;fill:none;stroke:currentColor;stroke-width:2;"><use href="#i-shield"/></svg></span>
            </div>
            <div class="stat-num" style="font-size:1.15rem;margin-top:6px;">Warming Up</div>
            <div class="stat-lbl">Hiring Readiness</div>
        </div>
    </section>

    <div class="mock-interview-grid" style="display: grid; grid-template-columns: 1fr; gap: 24px; margin-top: 20px;">
        
        <!-- Setup Card -->
        <section class="card" aria-label="Session Configuration" style="padding: 24px;">
            <h3 style="font-family:'Sora',sans-serif; font-size:1.15rem; font-weight:800; color:var(--brand-deep); margin-bottom:4px; display:flex; align-items:center; gap:8px;">
                <svg aria-hidden="true" style="width:18px;height:18px;fill:none;stroke:currentColor;stroke-width:2;"><use href="#i-sliders"/></svg> Session Configuration
            </h3>
            <p style="font-size:0.8rem; color:var(--muted); margin-bottom:20px;">Customize your practice parameters to launch the simulator.</p>

            <form id="setup-form" style="display:flex; flex-direction:column; gap:16px;">
                <input type="hidden" id="application-id" value="<?= esc((string) ($contextPreset['application_id'] ?? '0')) ?>">

                <div class="form-field">
                    <label class="lbl">Target Job Title</label>
                    <input type="text" id="job-title" class="input" value="<?= esc((string) ($contextPreset['job_title'] ?? '')) ?>" placeholder="e.g. Senior Frontend Architect, Product Manager" required>
                    <div style="font-size:0.74rem; color:var(--muted); margin-top:4px;">We'll tailor behavioral &amp; technical questions to mirror this role.</div>
                </div>

                <div style="display:grid; grid-template-columns:1fr 1fr; gap:16px;">
                    <div class="form-field">
                        <label class="lbl">Difficulty Level</label>
                        <select id="difficulty" class="select">
                            <option value="easy">Easy</option>
                            <option value="medium" selected>Medium</option>
                            <option value="hard">Hard (Challenging)</option>
                        </select>
                    </div>

                    <div class="form-field">
                        <label class="lbl">Question Context Pack</label>
                        <select id="question-pack" class="select">
                            <?php foreach ($questionPackLabels as $value => $label): ?>
                                <option value="<?= esc($value) ?>"><?= esc($label) ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                </div>

                <div style="display:grid; grid-template-columns:1fr 1fr; gap:16px;">
                    <div class="form-field">
                        <label class="lbl">Interview Mode</label>
                        <select id="interview-mode" class="select">
                            <option value="chat" selected>Chat-only (Text Responses)</option>
                            <option value="voice">Voice-enabled (Speak Answers)</option>
                        </select>
                    </div>
                </div>

                <?php if (!empty($contextPreset['job_title'])): ?>
                    <div class="notice notice--info">
                        <svg aria-hidden="true" style="width:15px;height:15px;fill:none;stroke:currentColor;stroke-width:2;"><use href="#i-bulb"/></svg>
                        <span><strong>Application-Aware Intelligence</strong>: This session is synchronized with details from your recent job application.</span>
                    </div>
                <?php endif; ?>

                <div style="margin-top: 10px;">
                    <button type="submit" class="btn btn-primary btn-block btn-lg" id="btn-start-session">
                        Launch Live Simulator Session
                    </button>
                </div>
            </form>
        </section>

        <!-- History Sidebar -->
        <section class="card" aria-label="Recent Sessions" style="padding: 24px;">
            <h3 style="font-family:'Sora',sans-serif; font-size:1.15rem; font-weight:800; color:var(--brand-deep); margin-bottom:4px; display:flex; align-items:center; gap:8px;">
                <svg aria-hidden="true" style="width:18px;height:18px;fill:none;stroke:currentColor;stroke-width:2;"><use href="#i-receipt"/></svg> Recent Sessions
            </h3>
            <p style="font-size:0.8rem; color:var(--muted); margin-bottom:20px;"><?= count($recentSessions) ?> Scored Sessions Completed</p>

            <div id="recent-sessions-list" style="display:flex; flex-direction:column; gap:12px; max-height:480px; overflow-y:auto; padding-right:4px;">
                <?php if (empty($recentSessions)): ?>
                    <div style="text-align:center; padding:32px 10px; color:var(--muted);">
                        <svg aria-hidden="true" style="width:36px;height:36px;color:var(--border);margin-bottom:10px;fill:none;stroke:currentColor;stroke-width:2;display:block;margin-left:auto;margin-right:auto;"><use href="#i-chat"/></svg>
                        <b style="display:block;font-size:0.86rem;color:var(--brand-deep);margin-bottom:4px;">No simulator history</b>
                        <p style="font-size:0.78rem; margin:0;">Launch your first session to build your interactive history.</p>
                    </div>
                <?php else: ?>
                    <?php foreach ($recentSessions as $session): ?>
                        <div class="session-history-item">
                            <div style="display:flex; justify-content:space-between; align-items:flex-start; gap:8px;">
                                <div>
                                    <strong style="font-size:0.88rem; color:var(--brand-deep); display:block;"><?= esc($session['job_title'] ?: 'Interview Session') ?></strong>
                                    <div style="font-size:0.72rem; color:var(--muted); margin-top:4px; display:flex; gap:6px; flex-wrap:wrap; align-items:center;">
                                        <span class="pill pill--closed" style="font-size:0.6rem; padding:1px 6px;"><?= esc(ucfirst((string) ($session['difficulty'] ?? 'medium'))) ?></span>
                                        <span><?= esc($questionPackLabels[$session['question_pack'] ?? 'general'] ?? ucfirst((string) ($session['question_pack'] ?? 'General'))) ?></span>
                                    </div>
                                </div>
                                <div style="text-align:right;">
                                    <span class="pill pill--success" style="font-weight:700; font-size:0.76rem; padding:4px 10px;">
                                        <?= esc((string) ($session['overall_score'] ?? 0)) ?>/10
                                    </span>
                                </div>
                            </div>
                            <div style="border-top:1px solid var(--border); margin-top:12px; padding-top:8px; display:flex; justify-content:space-between; font-size:0.72rem; color:var(--muted);">
                                <span>STAR Score: <strong class="text-brand"><?= esc((string) ($session['star_average'] ?? 0)) ?>/10</strong></span>
                                <span><?= esc((string) ($session['created_at'] ?? '')) ?></span>
                            </div>
                        </div>
                    <?php endforeach; ?>
                <?php endif; ?>
            </div>
        </section>

    </div>
</div>
<?= $this->endSection() ?>

<?= $this->section('scripts') ?>
<script>
    $(document).ready(function() {
        $('#setup-form').on('submit', function(e) {
            e.preventDefault();
            
            const btn = $('#btn-start-session');
            btn.prop('disabled', true).text('Preparing Session...');

            const jobTitle = $('#job-title').val().trim();
            const difficulty = $('#difficulty').val();
            const questionPack = $('#question-pack').val();
            const mode = $('#interview-mode').val();
            const appId = $('#application-id').val();

            if (!jobTitle) {
                toastr.error('Please enter a target job title.');
                btn.prop('disabled', false).text('Launch Live Simulator Session');
                return;
            }

            $.ajax({
                url: '<?= base_url('candidate/career-tools/mock-interview/initiate') ?>',
                type: 'POST',
                data: {
                    <?= csrf_token() ?>: '<?= csrf_hash() ?>',
                    job_title: jobTitle,
                    difficulty: difficulty,
                    question_pack: questionPack,
                    mode: mode,
                    application_id: appId
                },
                success: function(res) {
                    if (res.success && res.session_id) {
                        toastr.success('Session prepared! Redirecting...');
                        window.location.href = '<?= base_url('candidate/career-tools/mock-interview') ?>/' + res.session_id;
                    } else {
                        toastr.error(res.message || 'Failed to initiate mock interview session.');
                        btn.prop('disabled', false).text('Launch Live Simulator Session');
                    }
                },
                error: function(xhr) {
                    toastr.error('Failed to connect to the interview engine. Please try again.');
                    btn.prop('disabled', false).text('Launch Live Simulator Session');
                }
            });
        });
    });
</script>
<?= $this->endSection() ?>
