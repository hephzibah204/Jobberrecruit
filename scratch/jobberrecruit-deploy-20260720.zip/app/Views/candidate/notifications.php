<?= $this->extend('layouts/app') ?>

<?= $this->section('styles') ?>
<link rel="stylesheet" href="<?= base_url('css/candidate-profile.css') ?>">
<style>
.alerts-grid {
    display: grid;
    grid-template-columns: 1fr;
    gap: 20px;
    margin-top: 20px;
}
@media (min-width: 992px) {
    .alerts-grid {
        grid-template-columns: 1fr 1.8fr;
    }
}
</style>
<?= $this->endSection() ?>

<?= $this->section('content') ?>
<div class="content">

    <!-- Header Section -->
    <div class="page-head">
        <div>
            <h1><svg aria-hidden="true" style="width:22px;height:22px;fill:none;stroke:currentColor;stroke-width:2;"><use href="#i-bell"/></svg> Job Alerts</h1>
            <p>Get notified the moment new jobs match your criteria — never miss an opening.</p>
        </div>
    </div>

    <div class="alerts-grid">

        <!-- Left: Create Alert -->
        <section class="card" aria-label="Create job alert" style="padding: 24px;">
            <h3 style="font-family:'Sora',sans-serif; font-size:1.05rem; font-weight:800; color:var(--brand-deep); margin-bottom:18px; display:flex; align-items:center; gap:8px;">
                <svg aria-hidden="true" style="width:16px;height:16px;fill:none;stroke:currentColor;stroke-width:2;"><use href="#i-plus"/></svg> Create Job Alert
            </h3>

            <form id="alert-form" style="display:flex; flex-direction:column; gap:14px;">
                <div class="form-field">
                    <label class="lbl">Keyword</label>
                    <input type="text" name="keyword" class="input" placeholder="e.g. Software Developer" value="<?= esc($presetKeyword ?? '') ?>">
                </div>

                <div class="form-field">
                    <label class="lbl">Location</label>
                    <select name="location_id" class="select" required>
                        <option value="" disabled selected>Choose Location</option>
                        <?php foreach ($states as $state): ?>
                            <option value="<?= $state->id ?>" <?= ($presetLocationId ?? '') == $state->id ? 'selected' : '' ?>><?= esc($state->name) ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div class="form-field">
                    <label class="lbl">Frequency</label>
                    <select name="frequency" class="select">
                        <option value="daily">Daily</option>
                        <option value="weekly">Weekly</option>
                        <option value="monthly">Monthly</option>
                    </select>
                </div>

                <div class="form-field">
                    <label class="lbl">Delivery Time</label>
                    <input type="time" name="delivery_time" class="input" value="08:00">
                </div>

                <div class="form-field">
                    <label class="lbl">Notification Channel</label>
                    <select name="channel" class="select">
                        <option value="email">Email (Default)</option>
                        <option value="sms" disabled>SMS (Not Available)</option>
                    </select>
                </div>

                <div style="margin-top: 8px;">
                    <button type="submit" class="btn btn-primary btn-block">
                        Create Alert
                    </button>
                </div>
            </form>
        </section>

        <!-- Right: Existing Alerts -->
        <section class="card" aria-label="Your alerts" style="padding: 24px;">
            <h3 style="font-family:'Sora',sans-serif; font-size:1.05rem; font-weight:800; color:var(--brand-deep); margin-bottom:18px; display:flex; align-items:center; gap:8px;">
                <svg aria-hidden="true" style="width:16px;height:16px;fill:none;stroke:currentColor;stroke-width:2;"><use href="#i-bell"/></svg> Your Alerts
            </h3>

            <div class="table-responsive">
                <table class="table" style="width:100%; border-collapse:collapse; font-size:0.84rem;">
                    <thead>
                        <tr style="border-bottom: 2px solid var(--border); text-align: left; color: var(--muted); font-weight: 700;">
                            <th style="padding:12px 8px;">Keyword</th>
                            <th style="padding:12px 8px;">Location</th>
                            <th style="padding:12px 8px;">Frequency</th>
                            <th style="padding:12px 8px;">Time</th>
                            <th style="padding:12px 8px;">Channel</th>
                            <th style="padding:12px 8px;">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (count($alerts) > 0): ?>
                            <?php foreach ($alerts as $alert): ?>
                                <tr style="border-bottom: 1px solid var(--border);">
                                    <td style="padding:14px 8px; font-weight:600; color:var(--brand-deep);"><?= esc($alert->keyword) ?></td>
                                    <td style="padding:14px 8px; color:var(--text);"><?= esc($alert->location_id ?: 'Any') ?></td>
                                    <td style="padding:14px 8px; color:var(--muted);"><?= ucfirst($alert->frequency) ?></td>
                                    <td style="padding:14px 8px; color:var(--muted); font-size:0.8rem;"><?= $alert->delivery_time ? date('g:i A', strtotime($alert->delivery_time)) : '—' ?></td>
                                    <td style="padding:14px 8px; color:var(--muted);"><?= ucfirst($alert->channel) ?></td>
                                    <td style="padding:14px 8px;">
                                        <button class="btn btn-outline btn-sm delete-alert" data-id="<?= $alert->id ?>">
                                            Delete
                                        </button>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="6" style="text-align:center; padding:32px; color:var(--muted);">
                                    No alerts created yet.
                                </td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </section>

    </div>
</div>
<?= $this->endSection() ?>

<?= $this->section('scripts') ?>
<script>
    $('#alert-form').on('submit', function(e) {
        e.preventDefault();

        $.ajax({
            url: "<?= site_url('candidate/alerts/save') ?>",
            type: "POST",
            data: $(this).serialize(),
            success: function(response) {
                if (response.success) {
                    toastr.success("Job alert created successfully");
                    setTimeout(() => location.reload(), 800);
                } else {
                    toastr.error(response.message);
                }
            },
            error: function() {
                toastr.error("Network error");
            }
        });
    });

    // Delete alert
    $('.delete-alert').on('click', function() {
        let id = $(this).data('id');

        if (!confirm("Delete this alert?")) return;

        $.post("<?= site_url('candidate/alerts/delete') ?>/" + id, {
            <?= csrf_token() ?>: "<?= csrf_hash() ?>"
        }, function(response) {
            if (response.success) {
                toastr.success("Alert deleted");
                setTimeout(() => location.reload(), 800);
            } else {
                toastr.error("Unable to delete alert");
            }
        });
    });
</script>
<?= $this->endSection() ?>