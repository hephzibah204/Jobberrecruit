<?= $this->extend('layouts/app') ?>

<?= $this->section('styles') ?>
<link rel="stylesheet" href="<?= base_url('css/candidate-profile.css') ?>">
<?= $this->endSection() ?>

<?= $this->section('content') ?>
<div class="content">

    <!-- Header Section -->
    <div class="page-head">
        <div>
            <h1><svg aria-hidden="true" style="width:22px;height:22px;fill:none;stroke:currentColor;stroke-width:2;"><use href="#i-bookmark"/></svg> Saved Jobs</h1>
            <p>Jobs you've saved for later review</p>
        </div>
    </div>

    <!-- Alert Notices -->
    <?php if (session()->getFlashdata('success')): ?>
        <div class="notice notice--info" style="margin-bottom: 16px;">
            <svg aria-hidden="true" style="width:16px;height:16px;fill:none;stroke:currentColor;stroke-width:2;"><use href="#i-check"/></svg>
            <span><?= esc(session()->getFlashdata('success')) ?></span>
        </div>
    <?php endif; ?>

    <?php if (session()->getFlashdata('error')): ?>
        <div class="notice notice--danger" style="margin-bottom: 16px; background:#fdf2f2; border-color:#fde8e8; color:#f05252;">
            <svg aria-hidden="true" style="width:16px;height:16px;fill:none;stroke:currentColor;stroke-width:2;"><use href="#i-x"/></svg>
            <span><?= esc(session()->getFlashdata('error')) ?></span>
        </div>
    <?php endif; ?>

    <!-- Table Card -->
    <section class="card" aria-label="Saved Jobs list" style="padding: 24px;">
        <div class="table-responsive">
            <table class="table" id="saved-jobs-table" style="width:100%; border-collapse:collapse; font-size:0.84rem;">
                <thead>
                    <tr style="border-bottom: 2px solid var(--border); text-align: left; color: var(--muted); font-weight: 700;">
                        <th style="padding:12px 8px;">Job Title</th>
                        <th style="padding:12px 8px;">Company</th>
                        <th style="padding:12px 8px;">Location</th>
                        <th style="padding:12px 8px;">Category</th>
                        <th style="padding:12px 8px;">Posted</th>
                        <th style="padding:12px 8px;">Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($savedJobs)): ?>
                        <tr>
                            <td colspan="6" style="text-align:center; padding:32px; color:var(--muted);">
                                <p style="margin-bottom:12px;">No saved jobs yet.</p>
                                <a href="<?= base_url('jobs') ?>" class="btn btn-primary btn-sm">Browse Jobs</a>
                            </td>
                        </tr>
                    <?php else: ?>
                        <?php foreach ($savedJobs as $job): ?>
                            <tr style="border-bottom: 1px solid var(--border);">
                                <td style="padding:14px 8px; font-weight:600; color:var(--brand-deep);"><?= esc($job->title) ?></td>
                                <td style="padding:14px 8px; color:var(--text);"><?= esc($job->company_name ?: 'N/A') ?></td>
                                <td style="padding:14px 8px; color:var(--muted);"><?= esc($job->location ?: 'N/A') ?></td>
                                <td style="padding:14px 8px; color:var(--muted);"><?= esc($job->category_name ?: 'N/A') ?></td>
                                <td style="padding:14px 8px; color:var(--muted); font-size:0.8rem;"><?= date('M d, Y', strtotime($job->created_at)) ?></td>
                                <td style="padding:14px 8px;">
                                    <div style="display:flex; gap:8px;">
                                        <a href="<?= site_url('jobs/view/' . $job->id) ?>" class="btn btn-primary btn-sm">
                                            View
                                        </a>
                                        <button type="button" class="btn btn-outline btn-sm unsave-job" data-job-id="<?= $job->id ?>">
                                            Unsave
                                        </button>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </section>

</div>
<?= $this->endSection() ?>

<?= $this->section('scripts') ?>
<script>
    document.querySelectorAll('.unsave-job').forEach(btn => {
        btn.addEventListener('click', function() {
            const jobId = this.dataset.jobId;
            if (!confirm('Remove this job from saved list?')) return;

            fetch('<?= base_url('job/unsave') ?>/' + jobId, {
                method: 'POST',
                headers: { 'X-Requested-With': 'XMLHttpRequest' }
            })
            .then(r => r.json())
            .then(data => {
                if (data.success !== false) {
                    this.closest('tr').remove();
                } else {
                    toastr.error(data.message || 'Failed to unsave job.');
                }
            })
            .catch(() => toastr.error('Network error. Please try again.'));
        });
    });
</script>
<?= $this->endSection() ?>

