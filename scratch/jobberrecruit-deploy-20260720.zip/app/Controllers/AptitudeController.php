<?php

namespace App\Controllers;

use App\Models\TestModel;
use App\Models\QuestionModel;
use App\Models\QuestionOptionModel;
use App\Models\TestAttemptModel;
use App\Models\AttemptAnswerModel;
use App\Models\CandidateTestResultModel;
use CodeIgniter\RESTful\ResourceController;

class AptitudeController extends BaseController
{
    public function index()
    {
        return view('candidate/aptitude/hub');
    }

    public function testEngine($attemptId)
    {
        $attemptModel = new TestAttemptModel();
        $attempt = $attemptModel->find($attemptId);
        
        if (!$attempt || $attempt['candidate_id'] != session()->get('user_id')) {
            return redirect()->to('/aptitude')->with('error', 'Test attempt not found or unauthorized.');
        }
        
        if ($attempt['status'] !== 'in_progress') {
            return redirect()->to("/aptitude/result/{$attemptId}");
        }

        $testModel = new TestModel();
        $test = $testModel->find($attempt['test_id']);

        return view('candidate/aptitude/test_engine', ['attempt' => $attempt, 'test' => $test]);
    }

    public function result($attemptId)
    {
        $attemptModel = new TestAttemptModel();
        $attempt = $attemptModel->find($attemptId);
        
        if (!$attempt || $attempt['candidate_id'] != session()->get('user_id')) {
            return redirect()->to('/aptitude')->with('error', 'Test result not found.');
        }

        if ($attempt['mode'] === 'practice') {
            return view('candidate/aptitude/result_practice', ['attempt' => $attempt]);
        } else {
            return view('candidate/aptitude/result_official', ['attempt' => $attempt]);
        }
    }

    // --- API Endpoints ---

    public function startAttempt()
    {
        $userId = session()->get('user_id');
        if (!$userId) return $this->response->setJSON(['status' => 'error', 'message' => 'Unauthorized'])->setStatusCode(401);

        $testId = $this->request->getPost('test_id');
        $mode = $this->request->getPost('mode') ?? 'practice';
        $employerRequired = $this->request->getPost('employer_required') ?? 0;
        $jobId = $this->request->getPost('job_id') ?? null;

        $testModel = new TestModel();
        $test = $testModel->find($testId);

        if (!$test) return $this->response->setJSON(['status' => 'error', 'message' => 'Test not found'])->setStatusCode(404);

        $attemptModel = new TestAttemptModel();

        // Rate limit for official mode (unless employer required)
        if ($mode === 'official' && !$employerRequired) {
            $lastOfficial = $attemptModel->where('candidate_id', $userId)
                                         ->where('test_id', $testId)
                                         ->where('mode', 'official')
                                         ->orderBy('started_at', 'DESC')
                                         ->first();
            if ($lastOfficial) {
                $daysSince = (time() - strtotime($lastOfficial['started_at'])) / (60 * 60 * 24);
                if ($daysSince < 30) {
                    return $this->response->setJSON([
                        'status' => 'error', 
                        'message' => 'Rate limit exceeded. You can only take an official test once every 30 days.'
                    ])->setStatusCode(429);
                }
            }
        }

        // Generate questions
        $questionModel = new QuestionModel();
        $allQuestions = $questionModel->where('test_id', $testId)->where('is_active', 1)->findAll();
        
        if (count($allQuestions) < $test['num_questions']) {
            return $this->response->setJSON(['status' => 'error', 'message' => 'Not enough questions in bank.'])->setStatusCode(500);
        }

        shuffle($allQuestions);
        $selectedQuestions = array_slice($allQuestions, 0, $test['num_questions']);
        $questionIds = array_column($selectedQuestions, 'id');

        $startedAt = date('Y-m-d H:i:s');
        $expiresAt = date('Y-m-d H:i:s', strtotime("+" . $test['duration_mins'] . " minutes"));

        $attemptData = [
            'candidate_id' => $userId,
            'test_id' => $testId,
            'mode' => $mode,
            'status' => 'in_progress',
            'started_at' => $startedAt,
            'expires_at' => $expiresAt,
            'question_ids' => json_encode($questionIds),
            'employer_required' => $employerRequired,
            'job_id' => $jobId
        ];

        $attemptId = $attemptModel->insert($attemptData);

        return $this->response->setJSON([
            'status' => 'success',
            'attempt_id' => $attemptId,
            'redirect' => "/aptitude/test/{$attemptId}"
        ]);
    }

    public function fetchTest($attemptId)
    {
        $userId = session()->get('user_id');
        $attemptModel = new TestAttemptModel();
        $attempt = $attemptModel->find($attemptId);

        if (!$attempt || $attempt['candidate_id'] != $userId) {
            return $this->response->setJSON(['status' => 'error', 'message' => 'Unauthorized'])->setStatusCode(401);
        }

        $questionIds = json_decode($attempt['question_ids'], true);
        $questionModel = new QuestionModel();
        $optionModel = new QuestionOptionModel();

        $questions = [];
        foreach ($questionIds as $qId) {
            $q = $questionModel->find($qId);
            if ($q) {
                $options = $optionModel->where('question_id', $qId)->findAll();
                shuffle($options); // Shuffle options
                
                // Strip out is_correct
                foreach ($options as &$opt) {
                    unset($opt['is_correct']);
                }

                $q['options'] = $options;
                // Never send explanation before submission
                unset($q['explanation']);
                
                $questions[] = $q;
            }
        }

        return $this->response->setJSON([
            'status' => 'success',
            'attempt' => $attempt,
            'questions' => $questions,
            'server_time' => time()
        ]);
    }

    public function saveAnswer($attemptId)
    {
        $userId = session()->get('user_id');
        $attemptModel = new TestAttemptModel();
        $attempt = $attemptModel->find($attemptId);

        if (!$attempt || $attempt['candidate_id'] != $userId || $attempt['status'] !== 'in_progress') {
            return $this->response->setJSON(['status' => 'error'])->setStatusCode(403);
        }

        $questionId = $this->request->getPost('question_id');
        $optionIds = json_encode($this->request->getPost('option_ids')); // Array of option IDs

        $answerModel = new AttemptAnswerModel();
        $existing = $answerModel->where('attempt_id', $attemptId)->where('question_id', $questionId)->first();

        if ($existing) {
            $answerModel->update($existing['id'], ['selected_option_ids' => $optionIds]);
        } else {
            $answerModel->insert([
                'attempt_id' => $attemptId,
                'question_id' => $questionId,
                'selected_option_ids' => $optionIds
            ]);
        }

        return $this->response->setJSON(['status' => 'success']);
    }

    public function submitTest($attemptId)
    {
        $userId = session()->get('user_id');
        $attemptModel = new TestAttemptModel();
        $attempt = $attemptModel->find($attemptId);

        if (!$attempt || $attempt['candidate_id'] != $userId || $attempt['status'] !== 'in_progress') {
            return $this->response->setJSON(['status' => 'error'])->setStatusCode(403);
        }

        $tabSwitches = (int) $this->request->getPost('tab_switches');
        $isFlagged = ($tabSwitches >= 4) ? 1 : 0;

        $testModel = new TestModel();
        $test = $testModel->find($attempt['test_id']);

        $answerModel = new AttemptAnswerModel();
        $answers = $answerModel->where('attempt_id', $attemptId)->findAll();
        
        $optionModel = new QuestionOptionModel();
        
        $numCorrect = 0;
        $numTotal = count(json_decode($attempt['question_ids'], true));

        // Re-check timing
        $isLate = (time() > strtotime($attempt['expires_at']) + 10); // 10 sec grace period

        foreach ($answers as $ans) {
            $selectedOptIds = json_decode($ans['selected_option_ids'], true);
            $isCorrect = 0;
            
            if (!$isLate && !empty($selectedOptIds)) {
                // simple MCQ logic (1 correct option)
                $optId = $selectedOptIds[0]; 
                $option = $optionModel->find($optId);
                if ($option && $option['is_correct'] == 1) {
                    $isCorrect = 1;
                    $numCorrect++;
                }
            }

            $answerModel->update($ans['id'], ['is_correct' => $isCorrect]);
        }

        $scorePct = ($numTotal > 0) ? ($numCorrect / $numTotal) * 100 : 0;
        $passed = ($scorePct >= $test['pass_threshold']) ? 1 : 0;

        $attemptModel->update($attemptId, [
            'status' => 'submitted',
            'submitted_at' => date('Y-m-d H:i:s'),
            'score_pct' => $scorePct,
            'passed' => $passed,
            'num_correct' => $numCorrect,
            'num_total' => $numTotal,
            'flagged' => $isFlagged
        ]);

        // Upsert CandidateTestResult if official
        if ($attempt['mode'] === 'official') {
            $resultModel = new CandidateTestResultModel();
            $existingResult = $resultModel->where('candidate_id', $userId)->where('test_id', $attempt['test_id'])->first();

            $showOnProfile = $passed ? 1 : 0;

            if ($existingResult) {
                if ($scorePct > $existingResult['best_score']) {
                    $resultModel->update($existingResult['id'], [
                        'best_score' => $scorePct,
                        'passed' => $passed,
                        'attempt_id' => $attemptId,
                        'achieved_at' => date('Y-m-d H:i:s')
                    ]);
                }
            } else {
                $resultModel->insert([
                    'candidate_id' => $userId,
                    'test_id' => $attempt['test_id'],
                    'best_score' => $scorePct,
                    'passed' => $passed,
                    'attempt_id' => $attemptId,
                    'show_on_profile' => $showOnProfile,
                    'achieved_at' => date('Y-m-d H:i:s')
                ]);
            }
        }

        return $this->response->setJSON([
            'status' => 'success',
            'redirect' => "/aptitude/result/{$attemptId}"
        ]);
    }
}
